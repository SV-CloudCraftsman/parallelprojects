package com.cg.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.cg.entity.TransactionEntity;

public interface BankDao2 extends JpaRepository<TransactionEntity, Integer> {
	
	@Query("from TransactionEntity where accNo=?1")
	List<TransactionEntity> printTransaction(Long accNo);

}
